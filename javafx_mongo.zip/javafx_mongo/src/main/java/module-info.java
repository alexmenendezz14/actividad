module com.example.javafx_mongo {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;
    requires com.almasb.fxgl.all;
    requires mongo.java.driver;

    opens com.example.javafx_mongo to javafx.fxml;
    exports com.example.javafx_mongo;
}