package com.example.javafx_mongo;

import com.mongodb.client.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import org.bson.Document;

public class HelloController {
    @FXML
    private Label welcomeText;
    @FXML
    private ListView<String> listView;

    @FXML
    protected void onHelloButtonClick() {
        MongoClient cliente = MongoClients.create("mongodb+srv://escritor:escritor@cluster0.1c5t1om.mongodb.net/\n");
        MongoDatabase db = cliente.getDatabase("sample_mflix");
        MongoCollection<Document> tabla = db.getCollection("comments");

        ObservableList<String> documentos = FXCollections.observableArrayList();
        MongoCursor<Document> cursor = tabla.find().iterator();
        while (cursor.hasNext()) {
            Document doc = cursor.next();
            documentos.add(doc.toJson());
        }
        listView.setItems(documentos);
    }
}


