package com.example.javafx_mongo;

public class HelloController {
}
